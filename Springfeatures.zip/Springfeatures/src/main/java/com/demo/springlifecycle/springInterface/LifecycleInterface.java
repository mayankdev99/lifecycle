package com.demo.springlifecycle.springInterface;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LifecycleInterface {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/demo/springlifecycle/springInterface/lifecycleinterfaceconfig.xml");
		
		context.registerShutdownHook();
		
	  Student stu=	(Student)context.getBean("stu1");
	  
	  System.out.println(stu);

	}

}
