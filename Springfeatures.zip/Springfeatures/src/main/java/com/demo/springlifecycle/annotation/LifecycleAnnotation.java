package com.demo.springlifecycle.annotation;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LifecycleAnnotation {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/demo/springlifecycle/annotation/lifecycleannotatationconfig.xml");
		
		context.registerShutdownHook();
		
		Product prd=(Product)context.getBean("prd1");
		
		System.out.println(prd.toString());
		

	}

}
